
extern char flag[];
extern char enc_flag[];
extern char otp[];

extern void koeri_crypt_init(int* data);
extern void koeri_crypt_scrub_flag();
extern char* koeri_encrypt_flag();